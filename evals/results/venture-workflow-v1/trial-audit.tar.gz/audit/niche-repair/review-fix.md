# Niche review repair
The prior report-quality omission is closed: NICHE now locally supplies interview questions, unchanged success bars, batch limits, stop rules and outward-authorization limits. No evidence or operator preference was invented.

Archived original reports/state/index/summary before edits in `before/`. Marked 61–67 stale, repaired 61, then explicitly revalidated each dependent (62 through 67) sequentially. Updated in-report input versions, state input hashes and output hashes; each downstream report records a brief-specific revalidation rationale. Scope revision stays 1 because buyer/pain/product/geography did not change. Original criteria and evidence packet did not change.

Actual snapshots and checker output for all 16 transitions are in `transitions/01` through `16`. Intermediate checks intentionally report stale/nonusable old inputs while affected stages remain stale. These are expected recovery-state diagnostics, not a claimed ready run. Final structural check and fresh-process recovery both pass; raw receipts are `check-final.txt` and `recovery-output.txt`.

This extends coverage to input-change invalidation/recovery and original-version preservation. It does not exercise a pivot, changed bars, new external evidence, or a fresh independent LLM session.

Post-trial root refinement now explicitly requires checking brief-specific content locally rather than deferring it downstream. Captured original source remains unchanged; the repair closes the omission under both versions. Parent will validate with the latest stricter schema_version integer check; saved manifest already uses integer 1.
