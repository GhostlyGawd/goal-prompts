from pathlib import Path
import hashlib,json,datetime,shutil,subprocess
R=Path('/tmp/venture-trial.OqM7Pp'); origin=Path('/Users/rhenmcleod/Repositories/goal-prompts')
for d in ['reports','sources','audit/transitions']: (R/d).mkdir(parents=True,exist_ok=True)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for x in ['family-venture',*map(str,range(60,68))]:shutil.copyfile(origin/f'raw/{x}.md',R/f'sources/{x}.md')
shutil.copyfile(origin/'workflows/venture_check.py',R/'sources/venture_check.py')
(R/'sources/packet.md').write_text('''# SIMULATION ONLY — not real venture evidence
Accessed/created 2026-09-14; event dates unspecified in the fixture.
S1: Three synthetic tutors report missed payments. No verbatim quotes, frequency, loss amounts, or payment commitments supplied.
S2: Two synthetic tutors use calendar reminders successfully. No cost, satisfaction scale, or relationship to S1 specified.
S3: An unnamed synthetic competitor lists USD 10/month. Billing unit is unspecified. No adoption proof, primary URL, feature list, homepage copy, or release history supplied.
S4: Operator can reach 12 tutors. No response rate, buying intent, geography verification, or acquisition history supplied.
S5: No verified willingness to pay is supplied. Absence is not evidence of zero willingness.
All sources are a single synthetic packet, not five independent external sources. The three and two tutors are fixture counts, not verified interviews or necessarily disjoint groups.
''')
(R/'OPERATOR.md').write_text('''# Authorized simulation fixture
Solo developer; 5 hours/week; USD 100/month; knows independent tutors. Existing selected venture TutorFollowup: US independent tutors, missed payment follow-up, automated reminders. Research through stages 60–67 authorized. Commits declined. Wedge selection and continuation delegated; no pivot authority. No external outreach or live browsing. Goals beyond evaluation unspecified; provisionally seek a small viable part-time venture, never assert income targets as operator preferences. This is an isolated disposable workspace; main-repository product charter is not the venture charter. No CHARTER.md here or in reports; suggest brief 149 at handoff. New workspace has no existing reports to preserve. Supplied local briefs take precedence over HTTP-fetch procedure in this offline trial.
''')
log=R/'audit/actions.jsonl'
def record(action,detail):
 with log.open('a') as f:f.write(json.dumps({'at':now(),'action':action,'detail':detail})+'\n')
record('intake','Read conductor and all 8 installed briefs, main repo charter for applicability, and operator fixture. Empty disposable workspace; no git and no commits. Local venture charter absent.')
criteria=[]
for id,threshold,evidence in [
('pain','At least 3 independent buyers report a recurring missed-payment problem with a concrete consequence in last 90 days.','Dated buyer accounts with frequency, consequence, and source independence.'),
('reachable_buyers','At least 10 relevant US independent tutors are credibly contactable.','Operator access plus confirmation of relevance and geography; contactability is not conversion.'),
('economics','At least 2 relevant buyers commit to a tested price and conservative positive monthly contribution fits USD 100/month cap.','Price commitments; measured variable and support costs; acquisition effort.'),
('operator_fit','Pilot delivery plus support and selling fits 5 hours/week and USD 100/month.','Timed pilot task and conservative support/sales workload.'),
('timing','A current purchase trigger or dated enabling change with a credible reason to act now.','Dated buyer trigger or primary evidence of changed constraint.'),
('unacceptable_risks','No demonstrated unmitigable consent, privacy, or delivery blocker for the proposed pilot.','Reviewed minimal data flow, permissions and delivery design; unknown is not cleared.')]:
 criteria.append(dict(id=id,threshold=threshold,evidence=evidence,recorded_at=now(),exposure='Before report conclusions; synthetic fixture facts already supplied, so not blind preregistration. Researcher-proposed provisional bars; no revisions.'))
files=['OPPORTUNITIES','NICHE','DEMAND','COMPETITORS','MARKET','POSITIONING','MOAT','VERDICT']
state=dict(schema_version=1,run_id='simulation-tutorfollowup-20260914',status='active',scope={'id':'tutorfollowup-us','revision':1,'buyer':'US independent tutors','pain':'missed payment follow-up','solution':'automated reminders'},operator={'skills':'solo developer','hours_per_week':5,'monthly_budget_usd':100,'access':'12 tutor contacts (simulation)','goal':'part-time viability is provisional; no income target supplied'},criteria=criteria,decisions=[{'at':now(),'authority':'supplied operator fixture','decision':'Evaluate TutorFollowup; keep buyer, pain, solution, geography fixed. All research authorized; commits no; wedge and continuation delegated; pivots not delegated. Offline installed sources expressly authorized.'}],commit_preference='no',next_step='Execute brief 60 against the fixed venture.',stages=[{'brief':str(i+60),'output':f'reports/{name}.md','status':'pending','inputs':{},'note':''} for i,name in enumerate(files)])
seq=0
def save(reason):
 global seq
 (R/'reports/venture-run.json').write_text(json.dumps(state,indent=2)+'\n')
 rows='\n'.join(f"| {s['brief']} | [{s['output']}]({Path(s['output']).name}) | {s['status']} | {1 if s['status']=='complete' else 0} | [installed brief](../sources/{s['brief']}.md) |" for s in state['stages'])
 bars='\n'.join(f"- **{c['id']}**: {c['threshold']} Required: {c['evidence']} Recorded: {c['recorded_at']}. Exposure: {c['exposure']}" for c in criteria)
 decisions='\n'.join(f"- {d['at']} — {d['decision']} Authority: {d['authority']}" for d in state['decisions'])
 (R/'reports/INDEX.md').write_text(f'''# 2026-09-14 — SIMULATION ONLY venture trial
Run: {state['run_id']}
Status: {state['status']}
Branch: no git. Commit preference: no. Charter paths: absent at root and reports/; suggest 149.
Selected venture: TutorFollowup, scope tutorfollowup-us@1. See [operator context](../OPERATOR.md).
Budget: one synthetic packet; eight local briefs; no live browsing, no outreach, purchases, publishing, implementation or commits. This compact trial evaluates workflow behavior only.
No existing reports; reuse/rerun/skip: fresh sequence authorized by trial request. Every completed report is a substantive insufficient-evidence analysis, not null.
## Original bars
{bars}
## Stages
| Brief | Report | Status | Findings (null separate: 0) | Actual source |
|---|---|---|---|---|
{rows}
Canonical brief URLs follow https://goal-prompts.vercel.app/raw/<brief>.md; installed source bytes and retrieval times/hashes are in venture-run.json. They were not fetched from the web.
## Decisions
{decisions}
## Unresolved questions
Frequency/severity, willingness to pay, US relevance of contacts, actual costs and workload, timing, consent/data design. Repeated packet use never increases independent corroboration.
## Next steps
1. Propose payment-history and price interviews; no outreach authority yet.
2. Time a dummy-data delivery walkthrough if later authorized.
3. Establish a venture charter using 149 if useful.
Exact next action: {state['next_step']}
## Resume instructions
Read INDEX.md, venture-run.json, OPERATOR.md, sources/family-venture.md and the scheduled brief. Verify hashes with `python3 sources/venture_check.py . --final` for this completed run. Inspect VERDICT.md and preserve all originals before any rerun. Only ask for unresolved authority; existing research and delegated wedge authority persist. No pivot, outreach, implementation or commit is authorized. See audit/actions.jsonl and audit/transitions/ for actual transitions. Optional proposed plan: brief 28 Roadmap Synthesis; brief 47 only after explicit implementation selection. No PR authority and no branch to publish.
''')
 seq+=1
 snap=R/f'audit/transitions/{seq:02d}'
 snap.mkdir()
 for name in ['INDEX.md','venture-run.json']:shutil.copyfile(R/'reports'/name,snap/name)
 record('transition',reason)
save('Initialized saved state and bars before report conclusions.')
content={
60:('TutorFollowup fits access but demand is unproved','''## Operator and bars
Evaluation mode; original six bars are recorded in INDEX and state before these conclusions. Solo developer, 5h/week, $100/month. Raw synthetic facts were already visible. Goals otherwise provisional.
## Field
| Candidate | Buyer/pain/solution/geography | Evidence | Fit assessment |
|---|---|---|---|
| TutorFollowup | US independent tutors; missed payments; automated reminders | S1/S4 | Access plausible; recurring pain and economics unknown |
Pain/reach/fit/timing scores omitted: discovery scoring does not establish evidence for this fixed candidate. Eight research lenses checked: complaints S1; operator access S4; shifts, unbundling, transfer, infrastructure growth, incumbent decay unknown; disconfirmation S2/S5.
## Shortlist
Only the operator-selected venture is assessed; no 10–15 invented alternatives. Keeping calendar reminders is its strongest competing alternative, not a newly selected venture.
## Next decision
Selection already supplied; preserve TutorFollowup. Cheapest test: verify recent missed-payment frequency and consequences before estimating demand.
''','Which candidate should be selected? Resolved by existing operator selection: TutorFollowup.'),
61:('Contacts provide a research channel, not customers','''## Map
| Cast/money/channel | Known or hypothesis |
|---|---|
| Buyer/user | Independent tutor is both, assumption to check |
| Payment flow | Learner or payer to tutor, hypothesis; actual arrangement unknown |
| Entry channel | 12 operator contacts, S4; relevance/geography unverified |
| Budget owner | Tutor, hypothesis; willingness to pay unknown |
## Directory
Only [operator network](../sources/packet.md) is available. No public forums or activity data supplied; no invented links or audience counts.
## Unwritten rules
Three provisional constraints: preserve payer relationships; avoid extra bookkeeping; respect messaging permission. They are hypotheses, not observed norms.
Three promising observations: missed payments reported (fixture-only confidence); known contacts (fixture-only confidence); existing calendar habit (fixture-only confidence, may defeat demand).
Buying trigger, trial and switching process are unobserved. Ask how the last missed payment was handled and who chooses tools.
''','Which unresolved niche question matters next? Prioritize recurring consequence; continuation delegated.'),
62:('Complaints do not establish willingness to pay','''## Evidence wall
| Source | Quote | Date | Sub-pain/independence/limits |
|---|---|---|---|
| S1 | None supplied | Event unknown; accessed 2026-09-14 | Three synthetic reports of missed payments; independence unverified |
Only 3 synthetic summaries, zero authentic quotes; requested 15–30 cannot be met under the one-packet budget. No fabricated quotes.
## Spend/workarounds
S2: two tutors successfully use calendars; costs and overlap with S1 unknown. S3: $10/month vendor price is not buyer spending. S5: no willingness-to-pay evidence. Search/hiring signals absent.
## Assessment
Separate grades use supported / partial / unknown: severity unknown (no consequence size), frequency unknown, independent evidence unknown, spend unknown. Strong opposing read: the task is adequately solved by calendars and not worth paying for. Neither demand nor its absence is established; gather missing evidence, continue desk synthesis under delegated authority.
## Next test
Propose asking 10 of 12 contacts about last 90 days and a $10/month offer. Pass pain bar only with 3 independent recurring-consequence accounts; price signal requires 2 explicit commitments. Stop or reconsider if no concrete recurring consequences among 10. No messages sent.
''','Continue, pivot pain, or gather evidence? Delegated decision: continue analysis and recommend gathering evidence; no pivot.'),
63:('A low price is a benchmark, not an entry gap','''## Matrix
| Alternative | Promise/features | Price | Traction |
|---|---|---|---|
| Unnamed synthetic competitor, S3 | Unprovided | $10/month; billing unit unknown | No proof |
| Calendar reminders, S2 | Successful reminders for two fixture tutors | Unknown | Two synthetic users only |
| Doing nothing/internal build/services | Unresearched alternatives | Unknown | Unknown |
## Complaint synthesis
No competitor-specific complaints supplied. S1 cannot be attributed to competitor defects. Homepage copy, changelogs, prior failed attempts and release activity unavailable.
## Gap analysis
Gap classification: unknown. Need both unmet demand and weak supply; neither established. Existing calendars are direct counterevidence to easy differentiation. Copying simple reminder functionality is a plausible mechanism, not a measured incumbent timeline.
## Wedge shortlist
One provisional wedge: payment follow-up reminders for the already selected tutors. No extra wedges padded from missing evidence. Disconfirm by showing existing calendar workflows already solve the reported payment problem adequately.
''','Which gap merits evaluation? Continue the fixed payment-follow-up hypothesis; no authorized pivot.'),
64:('The reachable network is small and conversion is unknown','''## Arithmetic
Source S4 gives 12 contacts, not 12 customers or a verified US market count. Assume test price $10 per tutor/month; S3 supports only a competitor monthly benchmark, not billing unit or acceptance. Annual price = 10 × 12 = $120/tutor/year.
TAM and addressable US tutor count unknown. Full-network ceiling = 12 × $120 = $1,440 annualized gross revenue, assuming 100% conversion and full-year retention; not forecast revenue.
## Timing
Why-now hypothesis: a recent missed-payment trigger could motivate action. Strong rebuttal: dates missing and existing calendars already work. No measured growth or changed constraint.
## Window
Illustrative end-year annualized scenarios, NOT forecasts: year 1 conservative/base/upside 0/2/4 retained users = $0/$240/$480 ARR; year 2 0/3/6 = $0/$360/$720 ARR. All conversion, timing, retention and capacity assumptions unverified; same 12-person network, no invented expansion. Real recognized revenue requires customer-months, unknown.
## Sensitivity/next test
Every retained tutor adds $120 ARR at the assumed price. Zero conversion yields $0 regardless of total market. Dominant assumption: willingness to switch/pay; seek 2 price commitments before treating base case as plausible. Stop plan expansion if none after 10 relevant conversations.
''','Proceed or narrow scope? Delegated continuation; preserve current scope and unresolved evidence.'),
65:('Use a provisional payment-follow-up wedge','''## Options
One supported research hypothesis only: US independent tutors, calendar alternative, payment-reminder tool category, proposed $10/tutor/month. Claim is a design intention, not verified outcome. Two/three options unsupported by packet; do not pad.
## Recommended wedge
Select payment-follow-up reminders within the fixed TutorFollowup buyer/pain/product scope under explicit delegated wedge authority. Selection is provisional for model testing, not validated differentiation. No pivot or scope revision. Calendar sufficiency and price resistance are strongest objections. No competitor copy supplied; live-copy comparison unavailable in authorized offline trial.
## Draft messages
Draft hypothesis: “TutorFollowup helps independent tutors remember payment follow-ups.” Avoid claiming recovered revenue, time saved, automation reliability or unique capabilities without a product/test. Automated reminders remain the solution hypothesis.
## Next test
Compare the draft against each contact’s actual calendar workflow and offer $10/month. Seek 2 explicit commitments among 10 relevant contacts. Flip condition: existing workflow sufficient or willingness to pay absent; any changed buyer/pain requires operator pivot authority and upstream revalidation. No outward test run.
''','Which wedge should be selected? Delegated selection recorded: payment-follow-up reminders, provisional.'),
66:('A subscription is plausible but operating costs are unmeasured','''## Models
Provisional $10/tutor/month subscription matches recurring-reminder hypothesis. Manual service could test value but time may dominate; usage billing lacks a measured value unit. No model has sourced buyer acceptance.
## Economics
Assumptions only, USD/month: price 10, variable cash cost 2/tutor, contribution = 10−2 = 8/tutor before labor/acquisition. Assumed fixed cash cost 20 gives cash break-even ceil(20/8)=3 users. At 12 users: revenue 120, variable 24, fixed 20, surplus 76 before labor. Monthly spend 44 fits 100 on these assumptions only.
Sensitivity: variable cost 8 gives contribution 2 and break-even 10; costs >=10 erase positive contribution. Model is not observed economics. Illustrative 1h/customer/month × 12 = 12h/month support + 8h/month sales/build = 20h/month, approximately the 5h/week capacity; spikes could exceed it. Labor value/CAC/payback unknown. No verified acquisition rate.
## Defenses/response
No evidenced moat. Reminder behavior could be copied; no documented timing. Data ownership, integration lock-in, supplier fees and permission design unknown; do not assume protective effects.
## Risk tests
1. Payment intent: 10 conversations, 3h/$0 proposed; pass 2 commitments, stop expansion at zero.
2. Workload/cost: dummy-data walkthrough, 1h/$0 proposed; pass conservative <=5h/week and <=$100/month, stop pilot if exceeded.
3. Permission/delivery: map minimal data and consent, 1h/$0 proposed; pass documented allowed flow and working dummy delivery, stop on unresolved blocker.
Tests are proposed only; external outreach or implementation needs authority.
''','Which risks next? Recommend price intent first; no outward tests authorized.'),
67:('Insufficient evidence is the justified simulation verdict','''## Bars
Original six bars are unchanged in INDEX/state. Recorded before report conclusions, with raw fixture exposure disclosed; no claim of blind preregistration. All seven prior scope stamps and input hashes verified before this assessment.
## Scorecard
| Bar | Result | Evidence and remaining issue |
|---|---|---|
| Pain | unknown | V62-001; three summaries lack dates/frequency/consequences |
| Reachable buyers | unknown | V61-001; 12 contacts but US relevance unverified; not customers |
| Economics | unknown | V66-001; no commitments or measured costs |
| Operator fit | unknown | V66-001; scenario fits narrowly but workload unmeasured |
| Timing | unknown | V64-001; no dated trigger or enabling change |
| Unacceptable risks | unknown | V66-001; permission/data/dependency checks absent |
No hard fail demonstrated; no averages, no automatic kill. All reports reuse one synthetic packet and add zero independent real-world evidence.
## Ruling
**Insufficient evidence.** Preserve TutorFollowup and provisional wedge. Calendar success is material counterevidence. Competitor price does not establish adoption; 12 contacts do not establish ten customers. Workflow completed; venture validation has not occurred.
## Next actions
1. Propose 10 conversations: resolve recurrence and price intent; 3h/$0; pass 3 recent recurring-consequence accounts and 2 $10/month commitments; stop expansion if no recurring pain or zero commitments. Obtain outreach authority first.
2. Propose dummy-data workload model: 1h/$0; pass <=5h/week and <=$100/month conservatively; stop on excess. No implementation implied.
3. Propose permission/delivery review: 1h/$0; pass documented allowed minimal-data flow; stop on unresolved blocker. This is a design question, no legal finding.
Five hours total proposed validation effort, not executed. Use 28 for an authorized merged plan, 47 only after implementation selection, and 149 for absent charter. No pivot/commit/publication authority implied.
''','Does the operator accept insufficient evidence or challenge an original bar? Final operator response pending; research sequence itself is complete.')}
for i,s in enumerate(state['stages']):
 # Rehydrate persisted prerequisites for every sequential stage.
 persisted=json.loads((R/'reports/venture-run.json').read_text()); assert persisted==state
 assert state['scope']['id']=='tutorfollowup-us'
 for prior in state['stages'][:i]:assert prior['status']=='complete' and hashfile(R/prior['output'])==prior['report_sha256']
 brief=(R/f"sources/{s['brief']}.md").read_text();assert '## Phase 4' in brief
 s['status']='running';s['inputs']={p['output']:p['report_sha256'] for p in state['stages'][:i]};save(f"Stage {s['brief']} running; index/state and prior hashes revalidated; installed brief read.")
 n=int(s['brief']);finding,body,closing=content[n]
 inputs='\n'.join(f'- [{Path(p).name}]({Path(p).name}): `{h}`' for p,h in s['inputs'].items()) or '- No earlier report inputs.'
 report=f'''# 2026-09-14 — {files[i].title()} (SIMULATION ONLY)
All Venture · stage {i+1}/8 · brief {n}
Run: {state['run_id']}
Scope: tutorfollowup-us@1
Brief: {n}
Status: complete

## Scope
US independent tutors; missed-payment follow-up; automated reminders. Synthetic offline behavioral QA, not real venture evidence. Charter absent; fixed selected candidate and provisional bars unchanged.

## Findings
1. **V{n}-001 — {finding}**. This matters because access and complaints alone do not establish a viable paid service. Resolve the specified unknowns before any build or external test.

{body}
## Evidence
[Single synthetic packet](../sources/packet.md), S1–S5; created/accessed 2026-09-14; event dates unavailable. Fixture descriptions only; no authentic quotes or external citations. Primary sources, trends and independent verification absent. Repeated citations are not corroboration.
Input report versions:
{inputs}

## Counterevidence
Two fixture tutors successfully use calendars; no verified willingness to pay. Price and reach are proxies, not proof of purchases. Unknown severity/cost/timing could reverse the hypothesis. No live search was attempted under the explicit offline simulation scope.

## Next steps
{closing}
No outreach, purchases, code changes, commits or publishing performed. See stage-specific tests above; delegated continuation applies where recorded.
'''
 (R/s['output']).write_text(report)
 assert all('## '+h in report for h in ['Scope','Findings','Evidence','Counterevidence','Next steps'])
 s.update(status='complete',note='Substantive synthetic-only assessment; evidence gaps preserved, not null.',report_sha256=hashfile(R/s['output']),source={'url':(R/f"sources/{n}.md").as_uri(),'retrieved_at':now(),'sha256':hashfile(R/f'sources/{n}.md')})
 if n in [60,62,65]:state['decisions'].append({'at':now(),'authority':'operator selection' if n==60 else 'explicit operator delegation','decision':{60:'Revalidate scan for fixed TutorFollowup scope; proceed without candidate switch.',62:'Continue remaining research; gather missing evidence recommendation does not authorize outward tests or pivot.',65:'Select provisional payment-follow-up wedge within existing scope before 66–67.'}[n]})
 state['next_step']=f'Execute brief {n+1} using current saved hashes.' if n<67 else 'Present insufficient-evidence ruling; obtain operator response on accepting it or challenging a bar. Any outreach requires explicit authorization.'
 save(f'Stage {n} complete; reviewed required sections and limits; closing decision: {closing}')
 result=subprocess.run(['python3',str(R/'sources/venture_check.py'),str(R)],capture_output=True,text=True)
 (R/f'audit/check-{n}.txt').write_text(result.stdout+result.stderr+f'Exit code: {result.returncode}\n');assert result.returncode==0,result.stdout
state['status']='complete';save('Eight-stage research simulation complete, insufficient-evidence verdict; next validation actions remain unperformed.')
result=subprocess.run(['python3',str(R/'sources/venture_check.py'),str(R),'--final'],capture_output=True,text=True)
(R/'audit/check-final.txt').write_text(result.stdout+result.stderr+f'Exit code: {result.returncode}\n')
print(R);print(result.stdout);print('exit',result.returncode)
