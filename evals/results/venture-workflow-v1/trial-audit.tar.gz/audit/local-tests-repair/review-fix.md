# Fresh-session local-test review repairs
OPPORTUNITIES now has local pain/access success thresholds and interview/time stop rules. COMPETITORS defines calendar sufficiency versus unresolved consequences and bounds a prospective disconfirmation test. VERDICT includes timing follow-up inside its existing first experiment and explicitly keeps the ruling insufficient evidence while the original timing bar remains unknown.

All additions are proposed test rules/hypotheses, not new evidence. Original six criteria and tutorfollowup-us@1 scope are byte-equivalent JSON values. No pivot/outreach/action authorized or performed.

Original reports, state/index and summary archived under before/. Entire affected report chain 60–67 marked stale, then revalidated sequentially. Each report has a brief-specific review note and refreshed upstream/report hashes. Eighteen actual state/index transition snapshots and checker receipts are under transitions/01–18. Intermediate stale-input diagnostics were retained; final checker and fresh-process recovery both pass. Captured brief/checker source files remain unchanged.
