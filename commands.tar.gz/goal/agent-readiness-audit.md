---
description: "Is your repo legible to a coding agent — CLAUDE.md, discoverable conventions, one-command checks, and tools an agent can actually run."
---

# Goal: Agent Readiness Audit

You are working inside this repo. Mission: judge how well this repo supports a coding agent working in it — the way THIS catalog's briefs assume — and close the gaps that make an agent guess, thrash, or break things.

Read-only pass. Your only write is the report file.

## Phase 1 — Work it as an agent would
- Look for the map an agent reads first: a CLAUDE.md or equivalent, README, contributing docs. Is there a single place that states how to build, test, and check?
- Try to answer, from the repo alone: how do I run this, how do I verify a change, what conventions must I follow, what must I not touch?
- Note where you had to infer — every inference is a place a real agent would guess wrong.

## Phase 2 — Audit through 7 lenses
1. **Agent brief** — is there a CLAUDE.md (or similar) giving an agent the project's shape, commands, and guardrails? Missing, thin, or stale?
2. **One-command checks** — can build, test, lint, and typecheck each run with a single documented command, or must they be assembled from tribal knowledge (ties to 14)
3. **Convention discoverability** — are patterns (error handling, structure, naming) stated, or only inferable by osmosis from reading many files
4. **Feedback speed & clarity** — when an agent breaks something, does a check fail fast with a legible message, or silently/slowly?
5. **Safe boundaries** — is it clear what's generated, vendored, or dangerous to edit, so an agent doesn't hand-edit build output or secrets (ties to 26)
6. **Runnable tools** — scripts and tasks an agent can invoke non-interactively; or do key operations require a human clicking through a UI
7. **Context economy** — can an agent build a correct mental model without reading the whole tree: clear entry points, module boundaries, a legible layout (ties to 27)

## Phase 3 — Curate
- Rank gaps by how early and how often an agent hits them: first-five-minutes blockers first
- Every gap names the artifact that fixes it (a CLAUDE.md section, a check script, a one-line convention note)

## Phase 4 — Report
Create `AGENT-READINESS.md` at repo root:
1. **Readiness verdict** — could an agent be productive here in five minutes? Honestly, with the breakdown
2. **The inference log** — what you had to guess, and what an agent would likely get wrong
3. **Findings** — each: gap · lens · fix (the artifact) · effort
4. **Proposed CLAUDE.md outline** — the sections this repo specifically needs
5. **The one-hour fix** — the single artifact that most improves agent legibility

## Rules
- Judge by what the repo tells an agent, not what a maintainer happens to know
- A one-command check is worth more to an agent than a page of prose describing the steps
- Report only — end by asking which artifacts to create
