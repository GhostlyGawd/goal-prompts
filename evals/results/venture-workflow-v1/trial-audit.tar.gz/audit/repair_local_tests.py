from pathlib import Path
import json,hashlib,datetime,shutil,subprocess,re
R=Path(__file__).resolve().parents[1];A=R/'audit/local-tests-repair';A.mkdir()
shutil.copytree(R/'reports',A/'before/reports');shutil.copyfile(R/'trial-results.md',A/'before/trial-results.md')
s=json.loads((R/'reports/venture-run.json').read_text());old=json.loads(json.dumps(s));index=(R/'reports/INDEX.md').read_text();seq=0
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(event):
 global seq
 seq+=1;(R/'reports/venture-run.json').write_text(json.dumps(s,indent=2)+'\n')
 current=index.replace('Status: complete',f"Status: {s['status']}",1)
 for st in s['stages']:current=re.sub(rf'(\| {st["brief"]} \| .*? \| )complete( \|)',rf'\g<1>{st["status"]}\2',current)
 current+='\n## Fresh-session review repair\nOriginals: `audit/local-tests-repair/before/`. Current transition: '+event+'\n'
 current+='\n'.join(f"- {d['at']}: {d['decision']} Authority: {d['authority']}" for d in s['decisions'][len(old['decisions']):])
 current+='\nCurrent exact next action: '+s['next_step']+'\n';(R/'reports/INDEX.md').write_text(current)
 snap=A/f'transitions/{seq:02d}';snap.mkdir(parents=True)
 for name in ['INDEX.md','venture-run.json']:shutil.copyfile(R/'reports'/name,snap/name)
 with (R/'audit/actions.jsonl').open('a') as f:f.write(json.dumps({'at':now(),'action':'local-tests review repair','detail':event})+'\n')
 result=subprocess.run(['python3',str(R/'sources/venture_check.py'),str(R)],capture_output=True,text=True)
 (snap/'check.txt').write_text(result.stdout+result.stderr+f'Exit code: {result.returncode}\n');return result
additions={
'60':'''### Local test thresholds — proposed, not executed
After explicit outreach authorization, ask up to 10 relevant US independent tutors from the 12-contact network about missed payments in the last 90 days (shared interview batch, at most 3 hours/$0). Success for the original pain bar: at least 3 independent accounts of recurring missed payments with concrete consequences. Confirm at least 10 relevant contactable tutors for the access bar; this does not show purchases. Stop the batch at 10 relevant conversations or 3 hours. With no recurring consequences, stop expansion and ask the operator to reconsider the hypothesis; 1–2 accounts leave the bar unmet and warrant additional evidence, not an invented kill decision. Do not change the selected venture without authority.
''',
'63':'''### Bounded calendar-sufficiency test — proposed, not executed
Within the same authorized-only batch of up to 10 relevant interviews and 3 hours/$0, ask each tutor to reconstruct the last missed payment, show how their existing calendar workflow handled follow-up, and identify any recurring consequence left unresolved. Operational sufficient-workaround response: the tutor reports no recurring follow-up consequence left unresolved by that workflow and no desire to replace it. Operational unmet-workaround response: a dated recurring missed-payment consequence persists despite the workflow. These definitions and thresholds are research hypotheses, not observed outcomes or revisions to the venture bars.
A provisional underserved-gap hypothesis needs at least 3 independent unmet-workaround responses plus the original 2 price commitments; it still needs later supply comparison. If at least 7 of 10 describe a sufficient workaround and fewer than 3 describe an unmet workaround, stop the gap claim and retain unknown pending operator review. Inconclusive responses, fewer than 10 interviews or zero commitments do not establish an opportunity. Stop at the batch/time limit; no extra interviews, product trial, or pivot is authorized.
''',
'67':'''### Timing follow-up and decision gate — proposed, not executed
Include in next action 1's existing 10-conversation/3-hour/$0 batch: “When did the latest missed-payment problem occur, what made you consider changing your follow-up now, and what would happen if you waited three months?” Ask permission to verify any dated workflow artifact; no outreach or artifact access has occurred. Record calendar success and “nothing changed” responses as counterevidence.
The original timing bar passes only if follow-up yields a corroborated current buyer purchase trigger or a dated enabling change with a credible reason to act now. A purchase-trigger statement remains prospective buyer evidence, not a sale; do not infer urgency from the synthetic complaint counts. If no dated trigger/change emerges within the bounded batch, timing stays unknown and the ruling stays insufficient evidence even if pain and price signals improve. Any bar challenge must be dated and explicit. This is a follow-up within the existing first test, not a fourth experiment or a changed original threshold.
'''}
reason={
'60':'Added local pain/access success criteria and bounded stop rules from original bars; no new candidate or evidence.',
'61':'Reviewed revised Opportunity test against local Niche questions and thresholds: aligned; fixed scope and access uncertainty unchanged.',
'62':'Reviewed upstream local thresholds: unchanged pain/spend bars and shared batch. Complaints still do not establish willingness to pay.',
'63':'Added bounded calendar-sufficiency definitions and provisional test thresholds; no observed competitor or buyer evidence added. Gap remains unknown.',
'64':'Reviewed revised test plans: no new counts, conversions, price acceptance or dates; market scenarios and timing uncertainty unchanged.',
'65':'Reviewed refined gap test: it proposes evidence collection only; fixed provisional wedge remains selected under existing delegation, no pivot.',
'66':'Reviewed refined upstream tests: no measured costs, adoption or defense; economics/fit uncertainty and model assumptions remain unchanged.',
'67':'Added timing follow-up within the existing first experiment and explicit unknown-timing gate. Original six bars unchanged; all remain unknown, ruling remains insufficient evidence.'}
s['status']='active';s['next_step']='Repair local tests in 60/63/67 and sequentially revalidate every affected report.'
s['decisions'].append({'at':now(),'authority':'explicit parent fresh-session review repair task','decision':'Archive current originals; mark 60–67 stale; add proposed local test thresholds and timing gate, then revalidate sequentially. No new evidence, scope change or bar revision.'})
for st in s['stages']:st['status']='stale';st['note']='Fresh-session review requires local test/gate repairs in upstream reports; revalidation pending.'
save('Archived all current reports; marked full affected chain 60–67 stale before edits. Intermediate stale diagnostics expected.')
for i,st in enumerate(s['stages']):
 b=st['brief'];p=R/st['output'];text=p.read_text();brief=(R/f'sources/{b}.md').read_text();assert '## Phase 4' in brief
 for dep in s['stages'][:i]:
  assert dep['status']=='complete' and h(R/dep['output'])==dep['report_sha256'];assert 'Scope: tutorfollowup-us@1' in (R/dep['output']).read_text()
 st['inputs']={dep['output']:dep['report_sha256'] for dep in s['stages'][:i]};st['status']='running';st['note']='Explicit current-input review for local-test repair.';s['next_step']=f'Revalidate brief {b} under unchanged bars and scope.'
 save(f'Brief {b} running; exact brief and current prior reports reviewed; dependency hashes verified.')
 for dep,sha in st['inputs'].items():text=text.replace(old['stages'][i]['inputs'][dep],sha)
 if b in additions:text=text.replace('## Next steps\n','## Next steps\n'+additions[b]+'\n',1)
 text+='\n## Fresh-session review revalidation\n'+reason[b]+' The added test rules are prospective hypotheses, not simulated observations.\n'
 p.write_text(text);st['report_sha256']=h(p);st['status']='complete';st['note']=reason[b]
 s['decisions'].append({'at':now(),'authority':'authorized research continuation and explicit review repair','decision':f'Brief {b} revalidated: '+reason[b]})
 save(f'Brief {b} complete after local requirement and dependency review; updated report/input hashes.')
s['status']='complete';s['next_step']=old['next_step'];assert s['criteria']==old['criteria'] and s['scope']==old['scope']
assert save('All eight stages complete after local test repairs and sequential revalidation; insufficient-evidence ruling unchanged.').returncode==0
for name,cmd in [('check-final',['python3',str(R/'sources/venture_check.py'),str(R),'--final']),('recovery-output',['python3',str(R/'audit/recover.py')])]:
 result=subprocess.run(cmd,capture_output=True,text=True);(A/f'{name}.txt').write_text(result.stdout+result.stderr+f'Exit code: {result.returncode}\n');assert result.returncode==0,result.stdout
(A/'review-fix.md').write_text('''# Fresh-session local-test review repairs
OPPORTUNITIES now has local pain/access success thresholds and interview/time stop rules. COMPETITORS defines calendar sufficiency versus unresolved consequences and bounds a prospective disconfirmation test. VERDICT includes timing follow-up inside its existing first experiment and explicitly keeps the ruling insufficient evidence while the original timing bar remains unknown.

All additions are proposed test rules/hypotheses, not new evidence. Original six criteria and tutorfollowup-us@1 scope are byte-equivalent JSON values. No pivot/outreach/action authorized or performed.

Original reports, state/index and summary archived under before/. Entire affected report chain 60–67 marked stale, then revalidated sequentially. Each report has a brief-specific review note and refreshed upstream/report hashes. Eighteen actual state/index transition snapshots and checker receipts are under transitions/01–18. Intermediate stale-input diagnostics were retained; final checker and fresh-process recovery both pass. Captured brief/checker source files remain unchanged.
''')
with (R/'trial-results.md').open('a') as f:f.write('''\n## Fresh-session review follow-up — local tests repaired\n\nThe independent reviewer recovered the correct scope, authority, ruling and hashes, then identified three further local-content omissions. These are now closed: OPPORTUNITIES has local success/stop rules, COMPETITORS has a bounded operational calendar-sufficiency test, and VERDICT follows up the original timing bar inside its first experiment and keeps an explicit insufficient-evidence gate. Additions are proposed tests only. Archived prior versions and sequentially invalidated/revalidated the entire affected chain, preserving original criteria/scope and refreshing every input/output hash. Evidence packet unchanged. See `audit/local-tests-repair/review-fix.md`, `before/`, eighteen `transitions/` receipts, `check-final.txt` and `recovery-output.txt`. Final checks pass. Independent reviewer findings are reported by the parent; local recovery receipts remain fresh Python-process checks.\n''')
print(R);print((A/'check-final.txt').read_text())
