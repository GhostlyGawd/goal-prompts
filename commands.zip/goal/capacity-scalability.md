---
description: "Whether the system can absorb growth — more users, data, and load — and which bottleneck gives out first when traffic multiplies."
---

# Goal: Capacity & Scalability Audit

You are working inside this repo. Mission: find the part of the system that gives out first as it grows — the bottleneck that is comfortable today and saturated at 10x — and judge whether the architecture can scale to meet it.

Read-only pass. Read the architecture, data-access patterns, and resource limits; change nothing but the report file.

## Phase 1 — Trace the load path
- Follow a typical request and a heavy job through the system; note every resource each consumes.
- Identify the shared, finite resources: the database, connection pools, queues, memory, CPU.
- Note how close to their limits they run today.

## Phase 2 — Audit through 7 lenses
1. **The first bottleneck** — under 10x load, what saturates first: CPU, database, a pool, a queue
2. **Statefulness & scaling** — can the app scale horizontally, or does shared state pin it to one node
3. **Connection & pool limits** — database connections, worker pools, file descriptors that cap throughput
4. **Data growth** — queries and jobs that degrade as tables grow; missing archiving
5. **Queue & backpressure** — what happens when work arrives faster than it is processed
6. **Resource headroom** — how close to limits the system runs now; the margin before trouble
7. **Elasticity & cost** — does scaling happen automatically, and what does 10x cost

## Phase 3 — Curate
- Rank by how soon growth hits each: the resource nearest its ceiling at expected growth comes first.
- For each, name the fix — an index, horizontal scaling, a bigger pool, backpressure, archiving.
- Separate "raise the ceiling" from "change the architecture"; size each honestly.

## Phase 4 — Report
Create `CAPACITY.md` at repo root:
1. **Load path** — the resources a request and a heavy job consume, and their headroom
2. **First bottleneck** — what saturates first under growth, with the evidence
3. **Findings** — each: resource · limit · when growth hits it · the fix
4. **Scaling plan** — the changes ordered by when they will be needed

## Rules
- Scalability is about the first thing to break, not average utilization
- A stateful node that cannot be cloned is a ceiling, not a server
- Report only — end by asking which capacity limits to raise first
