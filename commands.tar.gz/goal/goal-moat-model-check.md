---
description: "Why this survives contact with incumbents and arithmetic — monetization options, napkin unit economics, defensibility paths, and the kill risks named out loud."
---

# Goal: Moat & Model Check

Mission: Test whether the selected wedge can survive competition and produce viable economics within the operator’s resources.

Read repo instructions, CHARTER.md and relevant notes/reports at root and in reports/. Charter constraints bound recommendations. In a conductor, read INDEX.md and venture-run.json for scope, criteria, decisions and input versions; otherwise record these in this report. Your only write is this report. No outreach, purchases or code changes.

## Phase 1 — Anchor
- Read selected POSITIONING.md wedge, NICHE.md buying process and COMPETITORS.md defenses, plus relevant demand/market evidence.
- Resolve wedge selection by operator or recorded delegation. State model candidates and missing inputs; preserve scope and decision bars.

## Phase 2 — Investigate
1. **Model fit** — subscription, usage, transaction or services against the value event and buying process.
2. **Economics** — revenue per customer minus variable service/support costs gives contribution margin; compare acquisition cost and payback. State currency, period and units. Conversion affects acquisition, not price units.
3. **Compounding** — data, networks, integration, workflow or brand: mechanism, ownership, timeline and evidence, not mere head start.
4. **Response** — top competitors’ ability and incentive to copy; timelines are hypotheses unless sourced.
5. **Dependencies** — platform/supplier terms, switching options and repricing scenarios.
6. **Operator fit** — capital, time, sales cycle and delivery capacity under conservative assumptions.
7. **Failure modes** — three to five material risks if supported, each with an observable warning.

## Phase 3 — Decide
- Compare models using sourced ranges and explicit assumptions; show break-even and sensitivity. No survivor is a valid answer.
- Convert testable risks into cheap pre-tests with cost/time, pass/fail threshold and stop rule. Do not run customer outreach or purchases.

## Phase 4 — Report
Create `MOAT.md` at repo root:
1. **Models** — comparison, selected/provisional model and reasoning.
2. **Economics** — input provenance, formulas, conservative scenario and uncertainty.
3. **Defenses/response** — mechanisms, timelines and strongest counterevidence.
4. **Risk tests** — ranked risks, tripwires, test costs, thresholds and next decision.

Start with today's date. If `MOAT.md` already exists, read it first and lead with what changed; preserve prior work before an authorized replacement. Include scope, input versions, stable finding IDs, evidence, counterevidence and next steps; use the conductor's metadata when supplied.

## Rules
- Separate direct evidence, proxies, inference and assumptions. Material factual claims need source links and access dates; date events too. Repeated citations are not independent evidence. Disclose inaccessible sources and shortfalls; never invent quotes or numbers.
- Include meaningful counterevidence and what would change the recommendation. Stop at the agreed research budget; if none, state a bounded search plan and unresolved gaps.
- If a `reports/` directory exists at the repo root, write the report there instead of the root.
- Before asking, present the top findings as a ranked list in plain words.
- No selected or explicitly provisional wedge after clarification? Write a one-paragraph null report naming the missing decision. Unknown economics can support an insufficient-evidence conclusion.
- Report only — end by asking which risks to validate next; research authorization alone does not authorize running outward tests.
