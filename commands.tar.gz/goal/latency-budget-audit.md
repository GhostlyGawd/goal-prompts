---
description: "Decompose the wall-clock of a real user action into a per-stage budget — find the tail, the serial chains, and the wait nobody measured."
---

# Goal: Latency Budget Audit

You are working inside this repo. Mission: take the user's most important action, decompose its wall-clock time stage by stage, and find where the seconds actually go — with attention to the tail, not just the average.

Read-only pass: trace, time where measurable, and reason about the rest. Your only write is the report file.

## Phase 1 — Pick the action and trace it
- Choose the highest-value user-perceived action (page load, search, a run kickoff, checkout).
- Trace every stage from user intent to visible result: client work, network hops, auth, queries, external calls, model calls, rendering.
- Time what you can; estimate the rest and mark it estimated. Build the timeline.

## Phase 2 — Audit through 7 lenses
1. **Stage decomposition** — where the wall-clock goes per stage; the one or two stages that dominate the budget
2. **Serial chains** — awaits that run one-after-another but don't depend on each other and could be parallel
3. **The tail** — p95/p99 vs p50: what makes the slow requests slow (cold caches, big tenants, retry paths); tail latency is what users remember
4. **Blocking the paint** — work done before the user sees anything, that could be deferred, streamed, or moved after first render
5. **External variance** — third-party and model calls whose latency you don't control; are they bounded, cached, or on the critical path unnecessarily
6. **Perceived vs actual** — where optimistic UI, skeletons, or streaming would cut felt latency even if wall-clock is fixed (ties to 42)
7. **Measurement gaps** — stages with no timing instrumentation, so regressions here would be invisible

## Phase 3 — Curate
- Assign a rough budget: how many ms each stage costs now vs a reasonable target
- Rank fixes by felt-latency-per-effort on the common path; separate real speedups from perceived-speed wins and note both

## Phase 4 — Report
Create `LATENCY.md` at repo root:
1. **The timeline** — stage · time now (measured/estimated) · target · notes
2. **Budget verdict** — where the action spends its time, and the dominant stage in one sentence
3. **Findings** — each: stage · issue · fix · expected saving · effort
4. **Parallelize / defer / stream list** — the structural wins, ordered
5. **Instrumentation to add** — so the budget can be tracked over time

## Rules
- Optimize the tail and the common path; a better average that hides a worse p99 is a regression
- Distinguish real latency cuts from perceived ones — ship both, but label which is which
- Report only — end by asking which fixes to make
