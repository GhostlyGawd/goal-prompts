---
description: "Instantiates the golden-path template into a fresh product repo and proves the gate bites — red fails, green passes — before any product code exists."
---

# Goal: Scaffold the Rails

You are working at the spot where a product repo should exist. Mission: instantiate the goal-prompts golden-path template into a new product repo and prove the harness bites — red fails, green passes — before a line of product code exists.

This is a Build brief: it writes files, but only after the operator approves the plan at the Phase 2 gate.

## Phase 1 — Locate the decision and the template
- Find the product decision: a `VERDICT.md` with a go ruling (at this root or in `reports/`), or the operator's explicitly named product. Quote it.
- Locate the template: the `template/` directory of the goal-prompts repo — a local checkout, or `git clone --depth 1 https://github.com/GhostlyGawd/goal-prompts`.
- Read `template/README.md` end to end; it is the contract for what you are about to create.

## Phase 2 — Audit readiness, then ask
Score the instantiation through these lenses; cite evidence:
1. **Verdict** — is there a documented go, or an explicit operator ask? A hunch is not a verdict.
2. **Mechanical verifiability** — can this product's quality be checked by commands: tests, schema validation, golden files, rubric-scored evals with a numeric floor? If quality is pure taste, say so — this harness is the wrong tool for it.
3. **Name and home** — repo name, local path, GitHub remote; what already exists there?
4. **Stack fit** — the template default is Python 3 stdlib + unittest, zero dependencies. Any deviation needs a DECISIONS.md entry; name it now.
5. **Operator duties** — what only a human can do: create the GitHub repo, make the `check` workflow a required status check, point CODEOWNERS at themselves.

Then stop. Report only — end by asking whether to instantiate as planned, adjust, or abort. Nothing is created until the operator answers.

## Phase 3 — Instantiate and prove
1. Copy `template/` to the product path; `git init`; `git config core.hooksPath .githooks`.
2. Run `scripts/check` — the pristine scaffold must pass green.
3. Run `scripts/check --prove-red` — it plants a failing canary test and asserts the gate goes red; a gate that cannot fail is not a gate. Capture both outputs.
4. Fill ADR-0001 in DECISIONS.md (product, date, deviations) and commit as `scaffold: <product> from goal-prompts template`.

## Phase 4 — Report
Create `SCAFFOLD.md` at repo root (the product repo's root):
1. **What exists now** — the scaffold's file tree, one line per top-level entry
2. **Harness proof** — the green run and the prove-red run, verbatim tails
3. **Operator TODOs** — the Phase 2 duties still open, as checkboxes
4. **Next** — run 142 · Spec the Product to write SPEC.md before any product code

Start the report with today's date. If `SCAFFOLD.md` already exists from a previous run, this repo is already scaffolded — verify the harness still bites and lead with what changed since.

## Rules
- Nothing is written before the Phase 2 gate; the operator's answer is the scope
- The harness layer (`scripts/`, `.githooks/`, `.github/`, `.claude/`, `tests/harness/`) ships exactly as the template wrote it — instantiation never edits it
- No go verdict and no operator-named product? Say so in a one-paragraph null report and stop — a null result is a valid finding.
- If a `reports/` directory exists at the repo root, write the report there instead of the root.
- Report only — end by asking at the Phase 2 gate before creating anything
