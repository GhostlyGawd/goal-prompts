---
description: "Audit every conversion surface — hero, pricing, signup, checkout — against eCommerce best practices, and rank the highest-leverage lifts for a first-time visitor."
---

# Goal: Conversion Rate Optimization

You are working inside this repo. Mission: audit the product's public surfaces — landing, pricing, signup, checkout, the key funnels — against conversion and eCommerce best practices, and rank the highest-leverage lifts. Judge everything through the eyes of a first-time visitor who knows nothing about the product or the niche.

Read-only pass. Run the app or read the templates and components that render these surfaces; your only write is the report file.

## Phase 1 — Map the conversion path
- List the surfaces in funnel order: entry/landing → value → pricing → signup/checkout → activation. Name the one action each must drive.
- For each, note who lands there (cold or warm) and the single question in their head at that moment.
- Locate what renders them: page/route components, copy, CTAs, forms, pricing, meta/OG tags.

## Phase 2 — Audit through 9 lenses
Cite the component and the exact copy or element for every finding.
1. **Clarity above the fold** — does the hero say what it is, who it's for, and the outcome, in one glance, in words a newcomer gets
2. **Value, not features** — capabilities translated to outcomes; the pain named and bridged; the benefit made concrete
3. **The one action** — a single obvious primary CTA per screen; its wording, contrast, and placement; the gap between intent and click
4. **Trust & risk reversal** — social proof, guarantees, security, transparency; what makes a stranger believe the claims
5. **Friction** — steps, fields, and decisions that can be cut; dead ends; the single leakiest moment
6. **Objections** — the top three reasons a visitor bounces, and whether the page answers them before they leave
7. **Pricing & offer** — legibility, anchoring, plan clarity; how obvious the path from interest to purchase is
8. **Scannability** — hierarchy, length, jargon; can the page be grasped in a ten-second skim
9. **Findable & shareable** — title, meta description, OG/share card, structured data, and speed signals that decide the click

## Phase 3 — Curate
- Rank by expected lift ÷ effort: what moves conversion most per hour of work.
- Separate proven best-practice fixes from hypotheses that need an A/B test — mark which is which.
- Flag anything that would cost trust, accessibility, or clarity if changed carelessly.

## Phase 4 — Report
Create `CRO.md` at repo root:
1. **Funnel map** — each surface · the action it must drive · its biggest leak
2. **Findings** — each: lens · location · what a first-time visitor experiences · the fix · expected lift (H/M/L) · effort (S/M/L)
3. **Top 5 lifts** — ranked by leverage, with the one to ship first and why
4. **Ship vs test** — which fixes are safe to make now, which deserve an experiment

Start the report with today's date. If `CRO.md` already exists from a previous run, read it first and lead with what changed since.

## Rules
- Every finding cites the surface and the exact copy or element — no generic advice
- Speak for the first-time visitor; assume zero prior knowledge of product or niche
- Prefer removing friction over adding persuasion
- No conversion points in this repo? Say so in a one-paragraph null report and stop — a null result is a valid finding.
- If a `reports/` directory exists at the repo root, write the report there instead of the root.
- Report only — end by asking which lifts to make
