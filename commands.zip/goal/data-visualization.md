---
description: "Every chart, graph, and metric put to the truth test — right form, honest axes, labeled and legible, accessible beyond color, and numbers that match their source."
---

# Goal: Data Visualization Audit

You are working inside this repo. Mission: audit every chart, graph, gauge, and headline metric the product renders — and find the ones that pick the wrong form, distort the scale, or leave the reader unable to tell what they are looking at.

Read-only pass. Render the charts in the running app or read the chart configs, data-shaping code, and components; your only write is the report file.

## Phase 1 — Inventory the visuals
- List every visualization: line, bar, area, pie/donut, scatter, table-as-chart, sparkline, gauge, big-number stat, map, heatmap.
- For each, note the question it answers, the data behind it, and the library or code that draws it.
- Capture the axes, scales, color mapping, and labels each one actually ships with.

## Phase 2 — Audit through 8 lenses
Cite the chart and its config or component for every finding.
1. **Right form for the question** — does the chart type fit the comparison (trend, part-to-whole, distribution, correlation); the pie with twelve slices
2. **Honest scale** — truncated or dual y-axes, inconsistent bins, log without saying so; the axis that turns a wiggle into a cliff
3. **Encodes the truth** — the drawn value matches the source data; rounding, unit, and aggregation that quietly mislead
4. **Legibility** — titles, axis labels, units, and legends present; can a stranger read it with no caption
5. **Color & accessibility** — categorical hues distinguishable and colorblind-safe, sequential ramps actually ordered, meaning never by color alone
6. **Data-ink & clutter** — gridlines, 3D, shadows, and decoration competing with the data; the ink spent on chrome
7. **Empty, loading & outliers** — no-data, still-loading, single-point, and extreme-value states; the chart that breaks on zero rows
8. **Interaction & responsive** — tooltips, hover, and legend toggles that work by keyboard and touch; the chart clipped on a phone

## Phase 3 — Curate
- Rank by decisions-at-risk: a distorted axis on the metric people act on outranks a cluttered decorative chart.
- Separate "wrong form", "misleading", and "unreadable"; fix misleading first — it costs trust.
- For each, name the chart, the flaw, and the truer rendering.

## Phase 4 — Report
Create `DATAVIZ.md` at repo root:
1. **Chart inventory** — chart · question it answers · form · data source
2. **Findings** — each: lens · chart · what the reader misreads · the fix
3. **Misleading-now** — the distortions to correct first, with the honest version
4. **The palette & defaults** — the shared chart colors, scales, and label rules this codebase should adopt

## Rules
- Every finding names the chart and the config or data behind it
- A chart that misleads is worse than no chart — correctness before beauty
- Report only — end by asking which charts to fix first
