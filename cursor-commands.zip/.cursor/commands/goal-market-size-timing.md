# Goal: Market Size & Timing

Mission: Estimate the reachable market and timing for the selected venture with visible arithmetic and conservative assumptions.

Read repo instructions, CHARTER.md and relevant notes/reports at root and in reports/. Charter constraints bound recommendations. In a conductor, read INDEX.md and venture-run.json for scope, criteria, decisions and input versions; otherwise record these in this report. Your only write is this report. No outreach, purchases or code changes.

## Phase 1 — Anchor
- Define the buyer unit, geography, wedge and annual value hypothesis from the selected scope and applicable NICHE/DEMAND/COMPETITORS reports.
- Collect countable primary proxies; separate total buyers, addressable buyers and buyers the operator could actually acquire.

## Phase 2 — Investigate
1. **Bottom-up** — count × annual price, with units, source dates and double-counting checks.
2. **Sanity check** — published totals only bound the model; explain large differences.
3. **Growth** — comparable observations over time; do not invent trends from one snapshot.
4. **Why now** — dated capability, behavior or regulatory shifts relevant to this buyer.
5. **Why not before** — prior attempts and evidence that their binding constraint changed.
6. **Window** — mechanism for early advantage versus waiting; strongest rebuttal.
7. **Concentration** — buyer/supplier dependencies and exposure to repricing.

## Phase 3 — Decide
- Model years one and two as conservative/base/upside ranges constrained by channel access, conversion, sales cycle and operator capacity; label unsupported inputs as assumptions.
- Show sensitivity and the bear case with equal effort. Market size does not establish demand.

## Phase 4 — Report
Create `MARKET.md` at repo root:
1. **Arithmetic** — input table, sources, assumptions and visible calculations.
2. **Timing** — why-now and strongest counterevidence side by side.
3. **Window** — reachable revenue ranges and operational constraints.
4. **Sensitivity/next test** — assumption most likely to flip the decision, and success/stop criterion.

Start with today's date. If `MARKET.md` already exists, read it first and lead with what changed; preserve prior work before an authorized replacement. Include scope, input versions, stable finding IDs, evidence, counterevidence and next steps; use the conductor's metadata when supplied.

## Rules
- Separate direct evidence, proxies, inference and assumptions. Material factual claims need source links and access dates; date events too. Repeated citations are not independent evidence. Disclose inaccessible sources and shortfalls; never invent quotes or numbers.
- Include meaningful counterevidence and what would change the recommendation. Stop at the agreed research budget; if none, state a bounded search plan and unresolved gaps.
- If a `reports/` directory exists at the repo root, write the report there instead of the root.
- Before asking, present the top findings as a ranked list in plain words.
- No defined buyer unit after clarification? Write a one-paragraph null report naming what is needed. Missing counts yield ranges or insufficient evidence, not invented totals.
- Report only — end by asking whether evidence supports the next stage or requires a narrower scope; honor an already delegated continuation.
