---
description: "The first session: empty states, a guided first action, and the fastest path to a first win that leaves a newcomer inspired to build the next thing."
---

# Goal: Activation & First-Win Audit

You are working inside this repo. Mission: judge the first session — from empty account to first real win — and whether it leaves a newcomer able and inspired to do the next thing. Signup is not activation; the first win is. This is where approachable is won or lost.

This audits the first session, after signup. For the funnel's structure end to end, run 09; for the persuasion that earns the signup, run 75.

Read-only pass. Run the app as a brand-new user if you can, or trace the first-run screens, empty states, and seed logic; your only write is the report file.

## Phase 1 — Walk the first session cold
- Enter as someone with an empty account and no context. Trace every screen from first login to first genuine value.
- Name the "first win" — the moment the product visibly does its job for this user — and count the steps, fields, and decisions before it.
- Note what greets a fresh account: a blank canvas, a wall of setup, a guided path, or sample data to play with.

## Phase 2 — Audit through 8 lenses
Cite the screen or component for every finding.
1. **Empty states that teach** — does the first blank screen invite and guide the first action, or describe emptiness and dead-end
2. **Time-to-first-win** — steps and minutes from entry to first real value; every gate before it that could move after it
3. **Guided first action** — is there one obvious next step, a template, or a sample to start from, or a cold "now what"
4. **Seed and sample data** — can a newcomer see the product working with real-looking content before doing the work of creating their own
5. **Setup tax** — configuration, connections, and permissions demanded up front that could be deferred until they're actually needed
6. **The inspiring next step** — after the first win, is there a clear, tempting second thing to try, or does momentum die at "done"
7. **Progress and reassurance** — does the newcomer always know where they are, what's left, and that they're doing it right
8. **Recover from a false start** — mistakes, wrong turns, and confusion in the first session: are they easy to undo and learn from

## Phase 3 — Curate
- Rank by distance to the first win: anything between a new user and that moment is the most expensive friction in the product.
- Every finding names the screen, the stall, and the newcomer's thought at that moment.
- Prefer deferring or defaulting a step over explaining it; the best onboarding is a shorter path, not a longer tour.

## Phase 4 — Report
Create `ACTIVATION.md` at repo root:
1. **First-session walk** — screen by screen to the first win, with findings inline
2. **Time-to-first-win** — the count today versus the achievable minimum
3. **Findings** — each: lens · location · what a newcomer feels · the fix · effort
4. **The one change** — the single fix that gets the most new users to their first win, and the second step it should tee up

Start the report with today's date. If `ACTIVATION.md` already exists from a previous run, read it first and lead with what changed since.

## Rules
- The first win is the goal; everything before it is tax to minimize
- A guided first step beats an empty canvas; sample data beats a blank one
- Inspire the next action — activation that ends at one win leaks tomorrow's habit
- No first-run experience in this repo? Say so in a one-paragraph null report and stop — a null result is a valid finding.
- If a `reports/` directory exists at the repo root, write the report there instead of the root.
- Report only — end by asking which fixes to make
