---
description: "How tightly the code is bound to specific vendors and clouds — and what it would cost to leave if pricing, terms, or reliability forced the issue."
---

# Goal: Vendor Lock-In Audit

You are working inside this repo. Mission: measure how dependent the product is on specific third-party vendors and clouds, and estimate the real cost of leaving — so lock-in is a known, priced risk rather than a surprise.

Read-only pass. Read the dependency surface, infra, and integration code; change nothing. Your only write is the report file.

## Phase 1 — Map the dependence
- List the vendors the product relies on: cloud, database, auth, payments, email, AI, analytics.
- For each, note how deeply it is woven in: bare SDK calls everywhere, or behind an interface.
- Identify which vendors are load-bearing — an outage or ban would stop the product.

## Phase 2 — Audit through 7 lenses
1. **Proprietary coupling** — vendor-specific APIs and SDKs threaded through the code with no abstraction
2. **Data gravity** — where the data lives and how hard or costly it is to extract and move
3. **Single points of vendor failure** — one provider whose outage takes the whole product down
4. **Managed-service dependence** — proprietary databases, queues, and auth with no portable equivalent
5. **Pricing & terms exposure** — usage-based costs that scale badly; terms that can change under you
6. **Portability seams** — where an adapter would isolate a vendor versus bare calls scattered around
7. **Exit cost** — a realistic estimate of the effort to migrate the top one or two dependencies

## Phase 3 — Curate
- Rank by likelihood × pain: a vendor with volatile pricing and deep coupling outranks a swappable one.
- Distinguish healthy dependence (use the managed service) from risky lock-in (cannot leave if you had to).
- For the worst, name the cheap abstraction that would buy optionality without a rewrite.

## Phase 4 — Report
Create `LOCKIN.md` at repo root:
1. **Dependence map** — vendor · surface · coupling depth · estimated exit cost
2. **Risks** — ranked by likelihood × pain, each with what triggers it
3. **Cheap optionality** — the adapters or seams worth adding before you need them
4. **Contingency** — for each load-bearing vendor, the rough plan if it had to change

Start the report with today's date. If `LOCKIN.md` already exists from a previous run, read it first and lead with what changed since.

## Rules
- Depending on a vendor is fine; being unable to leave one is the risk
- Price the exit before you are forced to pay it
- No third-party vendors in this repo? Say so in a one-paragraph null report and stop — a null result is a valid finding.
- If a `reports/` directory exists at the repo root, write the report there instead of the root.
- Report only — end by asking which lock-in risks to address first
