# Fresh Python process; reads saved artifacts only. No conversation input.
from pathlib import Path
import json,hashlib,importlib.util
root=Path(__file__).resolve().parents[1]
s=json.loads((root/'reports/venture-run.json').read_text())
sp=importlib.util.spec_from_file_location('check',root/'sources/venture_check.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
assert m.validate(root,True)==[]
print('Recovered run:',s['run_id'])
print('Scope:',s['scope'])
print('Run status:',s['status'])
print('Completed briefs:',','.join(x['brief'] for x in s['stages'] if x['status']=='complete'))
print('Commit preference:',s['commit_preference'])
print('Criteria:',len(s['criteria']))
print('Next step:',s['next_step'])
for d in s['decisions']:print('Authority receipt:',d['authority'],'=>',d['decision'])
for st in s['stages']:
 p=Path(st['source']['url'].removeprefix('file://'))
 assert hashlib.sha256(p.read_bytes()).hexdigest()==st['source']['sha256']
print('Recovery PASS: report/input/brief hashes valid; no pending stage, scope/authority/next action recoverable.')
print('Limit: separate-process artifact reconstruction, not an independent fresh LLM session.')
