# 2026-09-14 — Moat (SIMULATION ONLY)
All Venture · stage 7/8 · brief 66
Run: simulation-tutorfollowup-20260914
Scope: tutorfollowup-us@1
Brief: 66
Status: complete

## Scope
US independent tutors; missed-payment follow-up; automated reminders. Synthetic offline behavioral QA, not real venture evidence. Charter absent; fixed selected candidate and provisional bars unchanged.

## Findings
1. **V66-001 — A subscription is plausible but operating costs are unmeasured**. This matters because access and complaints alone do not establish a viable paid service. Resolve the specified unknowns before any build or external test.

## Models
Provisional $10/tutor/month subscription matches recurring-reminder hypothesis. Manual service could test value but time may dominate; usage billing lacks a measured value unit. No model has sourced buyer acceptance.
## Economics
Assumptions only, USD/month: price 10, variable cash cost 2/tutor, contribution = 10−2 = 8/tutor before labor/acquisition. Assumed fixed cash cost 20 gives cash break-even ceil(20/8)=3 users. At 12 users: revenue 120, variable 24, fixed 20, surplus 76 before labor. Monthly spend 44 fits 100 on these assumptions only.
Sensitivity: variable cost 8 gives contribution 2 and break-even 10; costs >=10 erase positive contribution. Model is not observed economics. Illustrative 1h/customer/month × 12 = 12h/month support + 8h/month sales/build = 20h/month, approximately the 5h/week capacity; spikes could exceed it. Labor value/CAC/payback unknown. No verified acquisition rate.
## Defenses/response
No evidenced moat. Reminder behavior could be copied; no documented timing. Data ownership, integration lock-in, supplier fees and permission design unknown; do not assume protective effects.
## Risk tests
1. Payment intent: 10 conversations, 3h/$0 proposed; pass 2 commitments, stop expansion at zero.
2. Workload/cost: dummy-data walkthrough, 1h/$0 proposed; pass conservative <=5h/week and <=$100/month, stop pilot if exceeded.
3. Permission/delivery: map minimal data and consent, 1h/$0 proposed; pass documented allowed flow and working dummy delivery, stop on unresolved blocker.
Tests are proposed only; external outreach or implementation needs authority.

## Evidence
[Single synthetic packet](../sources/packet.md), S1–S5; created/accessed 2026-09-14; event dates unavailable. Fixture descriptions only; no authentic quotes or external citations. Primary sources, trends and independent verification absent. Repeated citations are not corroboration.
Input report versions:
- [OPPORTUNITIES.md](OPPORTUNITIES.md): `b514ab5c0d931a3bc8761fc21bf77842eb945d6394d0c8c804b40226ccdb0890`
- [NICHE.md](NICHE.md): `49a09fa73d4fe4051f3e8c8f8ebfc6d4d84ea9db6cd4ea98edfa04297dc7fa8c`
- [DEMAND.md](DEMAND.md): `b9642a9a79a92cc3e24accdef2e2b1b49d89728cb4ffff8609c4f4023727ab1c`
- [COMPETITORS.md](COMPETITORS.md): `2feec88e80d76ee18a84475b96fcc39115f4e2c10a1dc0653da121bb68106fd0`
- [MARKET.md](MARKET.md): `7db3564dd7b7d46d9019889ba0b484e7e5d3e7d68378298fddd14945da97cb04`
- [POSITIONING.md](POSITIONING.md): `3a8678722decc0cc8721c4f076c5386e4d1e9a2deac40cfdb4560c8a3c138ba1`

## Counterevidence
Two fixture tutors successfully use calendars; no verified willingness to pay. Price and reach are proxies, not proof of purchases. Unknown severity/cost/timing could reverse the hypothesis. No live search was attempted under the explicit offline simulation scope.

## Next steps
Which risks next? Recommend price intent first; no outward tests authorized.
No outreach, purchases, code changes, commits or publishing performed. See stage-specific tests above; delegated continuation applies where recorded.
