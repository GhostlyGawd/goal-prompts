from pathlib import Path
import json,hashlib,datetime,shutil,subprocess,re
R=Path(__file__).resolve().parents[1]; A=R/'audit/niche-repair';A.mkdir()
shutil.copytree(R/'reports',A/'before/reports')
shutil.copyfile(R/'trial-results.md',A/'before/trial-results.md')
s=json.loads((R/'reports/venture-run.json').read_text());old=json.loads(json.dumps(s));index=(R/'reports/INDEX.md').read_text()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
seq=0

def save(event):
 global seq
 seq+=1
 (R/'reports/venture-run.json').write_text(json.dumps(s,indent=2)+'\n')
 current=index.replace('Status: complete',f"Status: {s['status']}",1)
 for stage in s['stages']:
  b=stage['brief'];current=re.sub(rf'(\| {b} \| .*? \| )complete( \|)',rf'\g<1>{stage["status"]}\2',current)
 current+='\n## Niche review repair — 2026-09-14 America/Chicago\n'
 current+=f"Archive: `audit/niche-repair/before/`. Current transition: {event}\n"
 current+='\n'.join(f"- {d['at']} — {d['decision']} Authority: {d['authority']}" for d in s['decisions'][len(old['decisions']):])
 current+=f"\nRepair next action: {s['next_step']}\n"
 (R/'reports/INDEX.md').write_text(current)
 snap=A/f'transitions/{seq:02d}';snap.mkdir(parents=True)
 for name in ['INDEX.md','venture-run.json']:shutil.copyfile(R/'reports'/name,snap/name)
 with (R/'audit/actions.jsonl').open('a') as f:f.write(json.dumps({'at':now(),'action':'review-repair transition','detail':event})+'\n')
 result=subprocess.run(['python3',str(R/'sources/venture_check.py'),str(R)],capture_output=True,text=True)
 (snap/'check.txt').write_text(result.stdout+result.stderr+f'Exit code: {result.returncode}\n')
 return result

s['status']='active';s['next_step']='Repair brief 61 local proposed-interview thresholds, then explicitly revalidate 62–67.'
s['decisions'].append({'at':now(),'authority':'explicit parent review-fix task within authorized simulation','decision':'Archive originals; repair local Niche test criteria; mark 62–67 stale and revalidate sequentially. Scope and original bars unchanged: this is an input-change recovery, not a pivot.'})
for stage in s['stages'][1:]:
 stage['status']='stale';stage['note']='Brief 61 review found missing local success/stop criteria. Archived versions remain historical; affected dependent reports cannot be evidence until revalidated.'
save('Marked 61–67 stale before editing; all originals archived. Stale-state checker failures expected while old input hashes reference stale reports.')

st=s['stages'][1];st['status']='running';save('Brief 61 running; opportunity hash and original criteria reviewed; no added evidence.')
p=R/st['output'];text=p.read_text();addition='''### Proposed interviews and local success/stop criteria
After explicit outreach authorization, propose up to 10 interviews through the 12-contact operator network (3 hours/$0 total, shared with the Demand test). First confirm US independent-tutor relevance, who selects tools, the last missed payment, its frequency/consequence, and whether calendars already suffice. No interviews have occurred.
Success: confirm at least 10 relevant contactable tutors for the access bar; find at least 3 independent accounts of recurring missed-payment consequences in the last 90 days for the pain bar. An optional $10/month offer tests the existing economics bar of at least 2 explicit price commitments; commitments alone do not establish positive contribution. These are proposed tests of the unchanged original bars, not findings.
Stop the planned interview batch at 10 relevant conversations or 3 hours. If access cannot be confirmed, pause recruitment claims; if no recurring consequences or zero commitments emerge, stop expansion and review the hypothesis with the operator. Intermediate results below the bars remain insufficient evidence. No pivot or outward action is authorized here.

'''
text=text.replace('## Next steps\n','## Next steps\n'+addition)
p.write_text(text);st['report_sha256']=h(p);st['status']='complete';st['note']='Review fix adds local questions and success/stop criteria from unchanged original bars. No new evidence.'
save('Brief 61 complete; local questions, success thresholds and stop rules reviewed. Downstream stages remain stale.')
reasons={
'62':'Niche local interview criteria match existing Demand test: 3 recent recurring-consequence accounts and 2 price commitments. No new testimony or spending proof; demand remains unknown.',
'63':'Added interview plan supplies no competitor facts, adoption, or weak-supply evidence; gap classification remains unknown.',
'64':'Added local thresholds do not change network size, geography uncertainty, conversion assumptions or timing; scenario arithmetic unchanged.',
'65':'Added questions retain buyer/pain/product/geography and calendar counterevidence. Existing delegated provisional wedge selection remains applicable; no pivot.',
'66':'Added tests do not measure willingness to pay, variable costs, labor or consent; economics assumptions and ranked risk tests remain provisional.',
'67':'Rechecked all six unchanged bars against refreshed prior reports; proposed interviews are not executed evidence. All six remain unknown and ruling remains insufficient evidence.'}
for i in range(2,8):
 st=s['stages'][i];b=st['brief'];prior=s['stages'][:i]
 for dep in prior:
  assert dep['status']=='complete' and h(R/dep['output'])==dep['report_sha256']
 # Read all current prior reports and the exact local brief at each transition.
 context=[(R/dep['output']).read_text() for dep in prior];brief=(R/f'sources/{b}.md').read_text()
 assert '## Phase 4' in brief and all('Scope: tutorfollowup-us@1' in t for t in context)
 st['inputs']={dep['output']:dep['report_sha256'] for dep in prior}
 st['status']='running';st['note']='Explicit revalidation after Niche quality repair; earlier report hashes verified.'
 s['next_step']=f'Revalidate brief {b} conclusions against changed Niche and current upstream versions.'
 save(f'Brief {b} running for revalidation; current prior reports/brief loaded and original bars preserved.')
 p=R/st['output'];text=p.read_text()
 for dep,sha in st['inputs'].items():
  previous=old['stages'][i]['inputs'][dep];text=text.replace(previous,sha)
 text+='\n## Review revalidation — 2026-09-14\n'+reasons[b]+' No synthetic source facts changed; this report retains its substantive conclusion after explicit input review.\n'
 p.write_text(text);st['report_sha256']=h(p);st['status']='complete';st['note']=reasons[b]
 s['decisions'].append({'at':now(),'authority':'authorized research continuation and review repair','decision':f'Brief {b} explicitly revalidated: '+reasons[b]})
 save(f'Brief {b} complete after explicit revalidation; report hash and every prior input hash updated.')
s['status']='complete';s['next_step']=old['next_step']
result=save('Niche omission repaired; all six dependents revalidated; fixed scope/original bars/insufficient-evidence ruling preserved.')
assert result.returncode==0,result.stdout
result=subprocess.run(['python3',str(R/'sources/venture_check.py'),str(R),'--final'],capture_output=True,text=True)
(A/'check-final.txt').write_text(result.stdout+result.stderr+f'Exit code: {result.returncode}\n');assert result.returncode==0
result=subprocess.run(['python3',str(R/'audit/recover.py')],capture_output=True,text=True)
(A/'recovery-output.txt').write_text(result.stdout+result.stderr+f'Exit code: {result.returncode}\n');assert result.returncode==0
(A/'review-fix.md').write_text('''# Niche review repair
The prior report-quality omission is closed: NICHE now locally supplies interview questions, unchanged success bars, batch limits, stop rules and outward-authorization limits. No evidence or operator preference was invented.

Archived original reports/state/index/summary before edits in `before/`. Marked 61–67 stale, repaired 61, then explicitly revalidated each dependent (62 through 67) sequentially. Updated in-report input versions, state input hashes and output hashes; each downstream report records a brief-specific revalidation rationale. Scope revision stays 1 because buyer/pain/product/geography did not change. Original criteria and evidence packet did not change.

Actual snapshots and checker output for all 16 transitions are in `transitions/01` through `16`. Intermediate checks intentionally report stale/nonusable old inputs while affected stages remain stale. These are expected recovery-state diagnostics, not a claimed ready run. Final structural check and fresh-process recovery both pass; raw receipts are `check-final.txt` and `recovery-output.txt`.

This extends coverage to input-change invalidation/recovery and original-version preservation. It does not exercise a pivot, changed bars, new external evidence, or a fresh independent LLM session.
''')
with (R/'trial-results.md').open('a') as f:f.write('''\n## Follow-up review repair — completed\n\nThe brief 61 omission identified above is now repaired. `reports/NICHE.md` includes local interview questions and success/stop criteria; all six dependents were marked stale and explicitly revalidated in sequence with refreshed hashes. No evidence, original bars or scope changed; verdict remains insufficient evidence. Original reports and this earlier summary were archived first. See `audit/niche-repair/review-fix.md`, its `before/` archive, `transitions/01`–`16`, and actual `check-final.txt` / `recovery-output.txt`. Input-change recovery and original-version preservation are now exercised; pivot recovery remains untested. Expected intermediate stale diagnostics were retained, and the repaired final run passes. Earlier statements about no checker failures describe the initial pass only.\n''')
print(R);print((A/'check-final.txt').read_text())
